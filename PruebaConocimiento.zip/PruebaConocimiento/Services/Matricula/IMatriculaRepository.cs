using PruebaConocimiento.Models;

namespace PruebaConocimiento.Services
{
    public interface IMatriculaRepository
    {
        IEnumerable<Matricula> GetAll();
        IEnumerable<Matricula> GetMatriculasByFecha(DateTime fecha);
        IEnumerable <Matricula> GetMatriculasByEstudianteId(int estudianteId);
        Matricula GetById(int id);
        void add (Matricula matricula);
        void update (Matricula matricula);
        void delete (int id);
    }
}