using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [Route("api/[controller]")]
    public class CrearProfesorController : ControllerBase
    {
        private readonly IProfesorRepository _profesorRepository;
        public CrearProfesorController(IProfesorRepository profesorRepository){
            _profesorRepository = profesorRepository;
        }
        [HttpPost]
        public IActionResult PostProfesor([FromBody]Profesor profesor)
        {
            _profesorRepository.add(profesor);
            return Ok("Profesor creado con exito");
        }
    }
}