using System.Text.Json.Serialization;
namespace PruebaConocimiento.Models;

public class Profesor
{
    public int Id { get; set; }
    public string? Nombre { get; set; }
    public string? Especialidad { get; set; }
    public string? Celular { get; set; }
    public string? Correo { get; set; }
    public int AñosExperiencia { get; set; }
    [JsonIgnore]
    public List <Curso>? Cursos { get; set; }
}