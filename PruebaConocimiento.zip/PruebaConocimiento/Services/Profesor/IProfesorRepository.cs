using PruebaConocimiento.Models;

namespace PruebaConocimiento.Services
{
    public interface IProfesorRepository
    {
        IEnumerable<Profesor> GetAll();
        Profesor GetById(int id);
        void add (Profesor profesor);
        void update (Profesor profesor);
        void delete (int id);
    }
}