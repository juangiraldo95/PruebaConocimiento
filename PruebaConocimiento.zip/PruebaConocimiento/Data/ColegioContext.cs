using PruebaConocimiento.Models;
using Microsoft.EntityFrameworkCore;

namespace PruebaConocimiento.Data
{
    public class ColegioContext : DbContext
    {
        public ColegioContext(DbContextOptions<ColegioContext> options): base(options)
        {

        }
        public DbSet<Curso> Cursos { get; set; }
        public DbSet<Estudiante> Estudiantes { get; set; }
        public DbSet<Matricula> Matriculas { get; set; }
        public DbSet<Profesor> Profesores { get; set; }
    }
}