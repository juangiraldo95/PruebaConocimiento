using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [ApiController]
    public class EstudiantesController : ControllerBase
    {
      private readonly IEstudianteRepository _context;
      public EstudiantesController(IEstudianteRepository context){
        _context = context;
      }
      [HttpGet]
      [Route("api/estudiantes")]
      public IEnumerable<Estudiante> GetEstudiantes(){
        return _context.GetAll();
      }
      [HttpGet]
      [Route("api/estudiante/{id}")]
      public Estudiante Details(int id){
        return _context.GetById(id);
      }
      [HttpGet("api/estudiantes/fechaNacimiento/{fechaNacimiento}")]
      public IActionResult GetEstudiantesByFechaNacimiento(DateTime fechaNacimiento)
      {
        var estudiantes = _context.GetEstudiantesByFechaNacimiento(fechaNacimiento);
        if (estudiantes == null || !estudiantes.Any())
        {
            return NotFound("No se encontro estudiante con esa fecha de nacimiento");
        }
        return Ok(estudiantes);
      }

    }
}