using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [ApiController]
    public class ProfesoresController : ControllerBase
    {
        private readonly IProfesorRepository _context;
        public ProfesoresController(IProfesorRepository profesorRepository){
            _context = profesorRepository;
        }
        [HttpGet]
        [Route("api/profesores")]
        public IEnumerable<Profesor> GetProfesores(){
            return _context.GetAll();
        }
        [HttpGet]
        [Route("api/profesor/{id}")]
        public Profesor Details (int id){
            return _context.GetById(id);
        }

    }
}