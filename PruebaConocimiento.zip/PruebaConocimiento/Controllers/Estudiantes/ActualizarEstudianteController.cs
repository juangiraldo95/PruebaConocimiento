using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [Route("[controller]")]
    public class ActualizarEstudianteController : ControllerBase
    {
        private readonly IEstudianteRepository _estudianteRepository;
        public ActualizarEstudianteController(IEstudianteRepository estudianteRepository){
            _estudianteRepository = estudianteRepository;
        }
        [HttpPut("{id}")]
        public IActionResult ActulizarEstudiante(int id, [FromBody] Estudiante estudiante){
            var EstudianteExistente = _estudianteRepository.GetById(id);
            EstudianteExistente.Id = estudiante.Id;
            EstudianteExistente.Nombre = estudiante.Nombre;
            EstudianteExistente.FechaNacimiento = estudiante.FechaNacimiento;
            EstudianteExistente.Direccion = estudiante.Direccion;
            EstudianteExistente.Correo = estudiante.Correo;

            _estudianteRepository.update(EstudianteExistente);
            return Ok("Paciente actualizado correctamente");

        }
    }
}