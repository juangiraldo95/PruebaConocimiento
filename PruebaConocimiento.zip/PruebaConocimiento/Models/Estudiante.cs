using System.Text.Json.Serialization;

namespace PruebaConocimiento.Models;

public class Estudiante
{
    public int Id { get; set; }
    public string? Nombre { get; set; }
    public DateTime FechaNacimiento { get; set; }
    public string?  Direccion { get; set; }
    public string? Correo { get; set; }
    [JsonIgnore]
    public List <Matricula>? Matriculas { get; set; }
}