using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [Route("[controller]")]
    public class CrearMatriculaController : ControllerBase
    {
        private readonly IMatriculaRepository _matriculaRepository;
        public CrearMatriculaController(IMatriculaRepository matriculaRepository){
            _matriculaRepository = matriculaRepository;
        }
        [HttpPost]
        public IActionResult PostMatricula([FromBody]Matricula matricula)
        {
            _matriculaRepository.add(matricula);
            return Ok("Matricula creada con exito");
        }
    }
}