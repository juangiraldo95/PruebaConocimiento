using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [Route("[controller]")]
    public class ActualizarMatriculaController : ControllerBase
    {
        private readonly IMatriculaRepository _matriculaRepository;
        public ActualizarMatriculaController(IMatriculaRepository matriculaRepository){
            _matriculaRepository = matriculaRepository;
        }
        [HttpPut("{id}")]
        public ActionResult PutMatriculaId(int id, [FromBody] Matricula matricula)
        {
            var MatriculaExistente = _matriculaRepository.GetById(id);
            MatriculaExistente.Id = matricula.Id;
            MatriculaExistente.Fecha = matricula.Fecha;
            MatriculaExistente.Estado = matricula.Estado;

            _matriculaRepository.update(MatriculaExistente);
            return Ok("Matricula actualizada correctamente");
        }
    }
}