using Microsoft.EntityFrameworkCore;
using PruebaConocimiento.Data;
using PruebaConocimiento.Models;

namespace PruebaConocimiento.Services
{
    public class EstudianteRepository : IEstudianteRepository
    {
        private readonly ColegioContext _context;
        public EstudianteRepository(ColegioContext context){
            _context = context;
        }
        public void add (Estudiante estudiante)
        {
            _context.Estudiantes.Add(estudiante);
            _context.SaveChanges();
        }
        public IEnumerable<Estudiante> GetAll()
        {
            return _context.Estudiantes.ToList();
        }
        public Estudiante GetById(int id)
        {
            return _context.Estudiantes.Find(id);
        }
        public void delete (int id)
        {
            var dueño = _context.Estudiantes.Find(id);
            _context.Estudiantes.Remove(dueño);
            _context.SaveChanges();
        }
        public void update (Estudiante estudiante)
        {
            _context.Estudiantes.Update(estudiante);
            _context.SaveChanges();
        }
        public IEnumerable<Estudiante> GetEstudiantesByFechaNacimiento(DateTime fechaNacimiento)
        {
            return _context.Estudiantes.Where(p => p.FechaNacimiento.Date == fechaNacimiento.Date).ToList();
        }
    }
}