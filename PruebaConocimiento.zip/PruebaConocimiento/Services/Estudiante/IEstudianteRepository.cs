using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PruebaConocimiento.Models;

namespace PruebaConocimiento.Services
{
    public interface IEstudianteRepository
    {
        IEnumerable<Estudiante> GetAll();
        IEnumerable<Estudiante> GetEstudiantesByFechaNacimiento(DateTime fechaNacimiento);
        Estudiante GetById(int id);
        void add(Estudiante estudiante);
        void update (Estudiante estudiante);
        void delete (int id);
    }
}