using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PruebaConocimiento.Models;

namespace PruebaConocimiento.Services
{
    public interface ICursoRepository
    {
       IEnumerable<Curso> GetAll();
       IEnumerable<Curso> GetCursoByProfesorId(int profesorId);
       Curso GetById(int id);
       void add (Curso curso);
       void update (Curso curso);
       void delete (int id);
    }
}