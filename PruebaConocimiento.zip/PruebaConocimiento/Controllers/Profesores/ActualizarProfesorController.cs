using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [Route("[controller]")]
    public class ActualizarProfesorController : ControllerBase
    {
        private readonly IProfesorRepository _profesorRepository;
        public ActualizarProfesorController(IProfesorRepository profesorRepository){
            _profesorRepository = profesorRepository;
        }
        [HttpPut("{id}")]
        public IActionResult ActualizarProfesor(int id, [FromBody] Profesor profesor)
        {
            var ProfesorExistente = _profesorRepository.GetById(id);

            ProfesorExistente.Id = profesor.Id;
            ProfesorExistente.Nombre = profesor.Nombre;
            ProfesorExistente.Especialidad = profesor.Especialidad;
            ProfesorExistente.Celular = profesor.Celular;
            ProfesorExistente.Correo = profesor.Correo;
            ProfesorExistente.AñosExperiencia = profesor.AñosExperiencia;

            _profesorRepository.update(ProfesorExistente);
            return Ok("Profesor actualizado correctamente");

        }
    }
}