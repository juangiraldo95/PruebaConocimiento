using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [Route("[controller]")]
    public class CrearCursoController : ControllerBase
    {
        private readonly ICursoRepository _cursoRepository;
        public CrearCursoController(ICursoRepository cursoRepository){
            _cursoRepository = cursoRepository;
        }
        [HttpPost]
        public IActionResult PostCurso([FromBody]Curso curso)
        {
            _cursoRepository.add(curso);
            return Ok("Curso creado con exito");
        }
    }
}