using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [Route("api/[controller]")]
    public class CrearEstudianteController : ControllerBase
    {
       private readonly IEstudianteRepository _estudianteRepository;
       public CrearEstudianteController(IEstudianteRepository estudianteRepository){
        _estudianteRepository = estudianteRepository;
       }
       [HttpPost]
        public IActionResult PostEstudiante([FromBody]Estudiante estudiante)
        {
            _estudianteRepository.add(estudiante);
            return Ok("Estudiante creado con exito");
        }
    }
}