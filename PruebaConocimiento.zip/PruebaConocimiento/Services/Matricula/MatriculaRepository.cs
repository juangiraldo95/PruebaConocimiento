using Microsoft.EntityFrameworkCore;
using PruebaConocimiento.Data;
using PruebaConocimiento.Models;

namespace PruebaConocimiento.Services
{
    public class MatriculaRepository : IMatriculaRepository
    {
        private readonly ColegioContext _context;
        public MatriculaRepository(ColegioContext context)
        {
            _context = context;
        }
        public void add(Matricula matricula)
        {
            _context.Matriculas.Add(matricula);
            _context.SaveChanges();
        }
        public IEnumerable<Matricula> GetAll()
        {
            return _context.Matriculas.Include(a => a.Estudiante).Include(b => b.Cursourso).ToList();
        }
        public Matricula GetById(int id)
        {
            return _context.Matriculas.Find(id);
        }
        public void delete (int id)
        {
            var matricula = _context.Matriculas.Find(id);
            _context.Matriculas.Remove(matricula);
            _context.SaveChanges();
        }
        public void update (Matricula matricula)
        {
            _context.Matriculas.Update(matricula);
            _context.SaveChanges();
        }
        public IEnumerable<Matricula> GetMatriculasByFecha(DateTime fecha)
        {
            return _context.Matriculas.Where(c => c.Fecha.Date == fecha.Date).Include(d => d.Estudiante).Include(e => e.Cursourso).ToList();
        }
        public IEnumerable<Matricula> GetMatriculasByEstudianteId(int estudianteId)
        {
            return _context.Matriculas.Where(c => c.EstudianteId == estudianteId).Include(d => d.Estudiante).Include(e => e.Cursourso).ToList();
        }
    }
}