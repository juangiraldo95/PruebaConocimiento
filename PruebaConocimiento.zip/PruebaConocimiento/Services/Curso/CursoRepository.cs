using Microsoft.EntityFrameworkCore;
using PruebaConocimiento.Data;
using PruebaConocimiento.Models;

namespace PruebaConocimiento.Services
{
    public class CursoRepository : ICursoRepository
    {
        private readonly ColegioContext _context;
        public CursoRepository (ColegioContext context){
            _context = context;
        }
        public void add (Curso curso)
        {
            _context.Cursos.Add(curso);
            _context.SaveChanges();
        }
        public IEnumerable<Curso> GetAll()
        {
            return _context.Cursos.Include(p => p.Profesor).ToList();
        }
        public Curso GetById(int id){
            return _context.Cursos.Find(id);
        }
        public void delete (int id)
        {
            var curso = _context.Cursos.Find(id);
            _context.Cursos.Remove(curso);
            _context.SaveChanges();
        }
        public void update (Curso curso)
        {
            _context.Cursos.Update(curso);
            _context.SaveChanges();
        }
        public IEnumerable<Curso> GetCursoByProfesorId(int profesorId)
        {
            return _context.Cursos.Where(c => c.ProfesorId == profesorId).Include(a => a.Profesor).ToList();
        }
    }
}