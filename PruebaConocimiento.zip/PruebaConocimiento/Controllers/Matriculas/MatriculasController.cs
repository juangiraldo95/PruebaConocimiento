using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [ApiController]
    public class MatriculasController : ControllerBase
    {
        private readonly IMatriculaRepository _context;
        public MatriculasController(IMatriculaRepository context){
            _context = context;
        }
        [HttpGet]
        [Route("api/matriculas")]
        public IEnumerable<Matricula> GetMatriculas(){
            return _context.GetAll();
        }
        [HttpGet]
        [Route("api/matricula/{id}")]
        public Matricula Details(int id){
            return _context.GetById(id);
        }
        [HttpGet("api/matriculas/fecha/{fecha}")]
        public IActionResult GetMatriculasByFecha(DateTime fecha)
        {
            var matriculas = _context.GetMatriculasByFecha(fecha);
            if (matriculas == null || !matriculas.Any())
            {
                return NotFound("No se encontraron matriculas para la fecha");
            }
            return Ok(matriculas);
        }
        [HttpGet("api/estudiante/{estudianteId}/matriculas")]
        public IActionResult GetMatriculasByEstudianteId(int estudianteId)
        {
            var matriculas = _context.GetMatriculasByEstudianteId(estudianteId);
            if (matriculas == null || !matriculas.Any())
            {
                return NotFound("Estudiante no encontrado o sin matriculas.");
            }
            return Ok(matriculas);
        }

        

        

    }
}