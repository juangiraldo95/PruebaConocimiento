using System.Text.Json.Serialization;

namespace PruebaConocimiento.Models;

public class Curso
{
    public int Id { get; set; }
    public string? Nombre { get; set; }
    public string? Descripcion { get; set; }
    public int ProfesorId { get; set; }
    public Profesor? Profesor { get; set; }
    public string? Horario { get; set; }
    public string? Duracion { get; set; }
    public int Capacidad { get; set; }
    [JsonIgnore]
    public List <Matricula>? Matricula { get; set; }
}