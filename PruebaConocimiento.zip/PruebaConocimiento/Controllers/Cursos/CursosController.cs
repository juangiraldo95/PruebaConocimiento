using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [ApiController]
    public class CursosController : ControllerBase
    {
        private readonly ICursoRepository _context;
        public CursosController(ICursoRepository context){
            _context = context;
        }
        [HttpGet]
        [Route("api/cursos")]
        public IEnumerable<Curso> GetCursos(){
            return _context.GetAll();
        }
        [HttpGet]
        [Route("api/curso/{id}")]
        public Curso Details(int id){
            return _context.GetById(id);
        }
        [HttpGet("api/profesor/{profesorId}/cursos")]
        public IActionResult GetCursoByProfesorId (int profesorId)
        {
            var cursos = _context.GetCursoByProfesorId(profesorId);
            if (cursos == null || !cursos.Any())
            {
                return NotFound("Profesor no encntrado o sin citas");
            }
            return Ok(cursos);
        }
    }
}