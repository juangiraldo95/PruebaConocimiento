using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PruebaConocimiento.Models;
using PruebaConocimiento.Services;

namespace PruebaConocimiento.Controllers
{
    [Route("[controller]")]
    public class ActualizarCursoController : ControllerBase
    {
        private readonly ICursoRepository _cursoRepository;
        public ActualizarCursoController(ICursoRepository cursoRepository){
            _cursoRepository = cursoRepository;
        }
        [HttpPut("{id}")]
        public ActionResult PutCursoId(int id, [FromBody] Curso curso)
        {
            var CursoExistente = _cursoRepository.GetById(id);
            CursoExistente.Id = curso.Id;
            CursoExistente.Nombre = curso.Nombre;
            CursoExistente.Descripcion = curso.Descripcion;
            CursoExistente.Horario = curso.Horario;
            CursoExistente.Duracion = curso.Duracion;
            CursoExistente.Capacidad = curso.Capacidad;

            _cursoRepository.update(CursoExistente);
            return Ok("Curso Actualizado con exito");
        }
    }
}