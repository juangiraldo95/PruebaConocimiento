using Microsoft.EntityFrameworkCore;
using PruebaConocimiento.Data;
using PruebaConocimiento.Models;

namespace PruebaConocimiento.Services
{
    public class ProfesorRepository : IProfesorRepository
    {
        private readonly ColegioContext _context;
        public ProfesorRepository(ColegioContext context){
            _context = context;
        }
        public void add (Profesor profesor)
        {
            _context.Profesores.Add(profesor);
            _context.SaveChanges();
        }
        public IEnumerable<Profesor> GetAll()
        {
            return _context.Profesores.ToList();
        }
        public Profesor GetById(int id)
        {
            return _context.Profesores.Find(id);
        }
        public void delete (int id)
        {
            var profesor = _context.Profesores.Find(id);
            _context.Profesores.Remove(profesor);
            _context.SaveChanges();
        }
        public void update (Profesor profesor)
        {
            _context.Profesores.Update(profesor);
            _context.SaveChanges();
        }
    }
}